const Discord = require('discord.js');
const client = new Discord.Client();
const settings = require('./settings.json');

client.on('ready', () => {
    console.log('The bot is online');

    //embed
exports.run = (client, message, args) => {
  const embed = new Discord.RichEmbed()
  .setColor(0xffff00)//the color for more colors search on google: "discord.js embed colors"
  .setThumbnail('http://database.nickgamesyt.nl/monobotlogo.png') //a picture in the embed
  .setFooter('MonoBot')//small text on the footer of the embed
  .addField('row 1', 'row 2')//first section row 1, second section row 2
  .addField('row 3', 'row 4')//first section row 3, second section row 4
  .addField('row 5', 'row 6')//first section row 5, second section row 6
  message.channel.sendEmbed(embed);
};

//message with mention
client.on('message', message => {
    if(message.content == "command that you wand") {
        message.reply('message that wil be sand be the bot')
    }
});

//message without mention
client.on('message', message => {
    if(message.content == "command that you wand") {
        message.channel.sendMessage('message that wil be sand be the bot')
    }
});


client.login(settings.token);